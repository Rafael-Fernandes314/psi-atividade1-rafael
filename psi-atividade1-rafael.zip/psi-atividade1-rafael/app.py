from flask import Flask, render_template, request, redirect, url_for
import models
from models import buscar_livro, buscar_livros, resenhas_do_livro

app = Flask(__name__)
app.secret_key = "batata"

@app.route('/')
def index():
    return url_for("index.html")
@app.route('/livro/<int:livro_id>')
def login():
    return None
@app.route('/livro/<int:livro_id>')
def logout():
    return None
@app.route('/livro/<int:livro_id>')
def livro():
    return None


if __name__ == '__main__':
    app.run()